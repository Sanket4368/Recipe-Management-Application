package com.humber.recipemanagementapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import com.humber.recipemanagementapplication.models.DessertRecipe
import com.humber.recipemanagementapplication.models.MainCourseRecipe

class AddEditRecipe : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_edit_recipe)

        val titleField: EditText = findViewById(R.id.input_title)
        val ingredientsField:EditText = findViewById(R.id.input_ingredients)
        val instructionField:EditText = findViewById(R.id.input_instructions)
        val categorySpinner: Spinner = findViewById(R.id.spinner_category)
        val sweetnessField:EditText = findViewById(R.id.input_sweetness)
        val prepTimeField: EditText = findViewById(R.id.input_preperation_time)
        val saveButton : Button = findViewById(R.id.save)
        val backButton : Button = findViewById(R.id.back)

        val categories = listOf("Dessert","Main Course")
        val adapter = ArrayAdapter(this,android.R.layout.simple_spinner_item,categories)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = adapter

        MainActivity.currentRecipe?.let { recipe ->
            titleField.setText(recipe.title)
            ingredientsField.setText(recipe.ingredients)
            instructionField.setText(recipe.instructions)

            when(recipe){
                is DessertRecipe ->{
                    categorySpinner.setSelection(categories.indexOf("Dessert"))
                    sweetnessField.setText((recipe.sweetnessLevel))
                    prepTimeField.isEnabled = false
                }
                is MainCourseRecipe ->{
                    categorySpinner.setSelection(categories.indexOf("Main Course"))
                    prepTimeField.setText(recipe.preparationTime.toString())
                    sweetnessField.isEnabled = false
                }
            }
        }
        saveButton.setOnClickListener {
            val title = titleField.text.toString()
            val ingredients = ingredientsField.text.toString()
            val instructions = instructionField.text.toString()
            val category = categorySpinner.selectedItem.toString()

            MainActivity.currentRecipe = when (category) {
                "Dessert" -> DessertRecipe(
                    id = 1,
                    title = title,
                    ingredients = ingredients,
                    instructions = instructions,
                    sweetnessLevel = sweetnessField.text.toString()
                )

                "Main Course" -> MainCourseRecipe(
                    id = 1,
                    title = title,
                    ingredients = ingredients,
                    instructions = instructions,
                    preparationTime = prepTimeField.text.toString().toInt()
                )

                else -> null
            }
            finish()
        }
        backButton.setOnClickListener {
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
    }
}