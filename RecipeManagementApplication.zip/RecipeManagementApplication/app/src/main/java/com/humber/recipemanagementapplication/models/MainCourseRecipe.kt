package com.humber.recipemanagementapplication.models

class MainCourseRecipe(
    id: Int,
    title: String,
    ingredients: String,
    preparationTime: Int,
    instructions: String

) : Recipe(id, title, ingredients, instructions , "Main Course") {
    var preparationTime: Int = preparationTime;
    override fun getDetails(): String {
        return super.getDetails() + """\n Preparation Time: $preparationTime minutes""".trimIndent();
    }
}